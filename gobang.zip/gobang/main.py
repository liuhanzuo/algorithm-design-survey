from tkinter import *
from game import *
g=Game()
g.mainloop()